import sys
import requests
from multiprocessing.dummy import Pool
from colorama import Fore, init

init(autoreset=True)
fr = Fore.RED
fg = Fore.GREEN

banner = '''{}
		   
███████╗██╗░░░██╗░█████╗░██╗░░██╗
██╔════╝██║░░░██║██╔══██╗██║░██╔╝
█████╗░░██║░░░██║██║░░╚═╝█████═╝░
██╔══╝░░██║░░░██║██║░░██╗██╔═██╗░
██║░░░░░╚██████╔╝╚█████╔╝██║░╚██╗
╚═╝░░░░░░╚═════╝░░╚════╝░╚═╝░░╚═╝

            Joomla Auto Upload shell Vulns Website
                  GARUDA SECURITY 
\n'''.format(fr)
print(banner)
requests.urllib3.disable_warnings()

try:
    target = [i.strip() for i in open(sys.argv[1], mode='r').readlines()]
except IndexError:
    path = str(sys.argv[0]).split('\\')
    exit('\n  [!] Enter <' + path[len(path) - 1] + '> <sites.txt>')

class EvaiLCode:
    def __init__(self):
        self.headers = {'User-Agent': 'Mozilla/5.0 (Linux; Android 7.0; SM-G892A Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/60.0.3112.107 Mobile Safari/537.36'}

    def URLdomain(self, site):
        if site.startswith("http://"):
            site = site.replace("http://", "")
        elif site.startswith("https://"):
            site = site.replace("https://", "")
        else:
            pass
        return site

    def checker(self, site):
        try:
            url = "http://" + self.URLdomain(site)
            common_paths = [
                '/administrator/manifests/files/joomla.xml',
                '/administrator/language/en-GB/en-GB.xml',
                '/templates/system/error.php',
                '/plugins/system/debug/debug.xml',
            ]
            for path in common_paths:
                check = requests.get(url + path, headers=self.headers, verify=False, timeout=25).content
                if "WSO 4.2.6" in check:
                    print('Target:{} --> {}[Successfully]'.format(url, fg))
                    open('vuln.txt', 'a').write(url + path + "\n")
                    break
                else:
                    print('Target:{} -->! {}[Failed]'.format(url, fr))
        except Exception as e:
            print(f"Error checking {site}: {e}")

Control = EvaiLCode()

def RunUploader(site):
    try:
        Control.checker(site)
    except Exception as e:
        print(f"Error processing {site}: {e}")

mp = Pool(50)
mp.map(RunUploader, target)
mp.close()
mp.join()
