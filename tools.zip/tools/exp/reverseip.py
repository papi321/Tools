from requests import get
from re import findall
from multiprocessing.dummy import Pool

print ("""

                          \033[33mDomain from ip
                  \033[35mGARSEC https://t.me/garudasec4   
                                                           
""")

def rev(ip) :
    try :
        url = 'https://api.reverseip.my.id/?ip='+ip
        send_data = get(url, timeout=10).text
        attack  = findall('"(.*?)"',send_data)[3:]
        for domain in attack :
            print(domain)
            open('site.txt','a').write('http://'+domain+'\n')
    except :
        pass
def main () :
    ad = input('\033[32mEnter list ip \033[37m: ')
    opens = open(ad, mode='r', errors='ignore').read().splitlines()
    utchiha = Pool(int(50))
    utchiha.map(rev, opens)
   

main()
