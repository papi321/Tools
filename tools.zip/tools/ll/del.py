def remove_duplicate_lines(input_file, output_file):
    unique_lines = set()

    # Membaca file input dan menyimpan baris unik ke dalam set
    with open(input_file, 'r') as infile:
        for line in infile:
            unique_lines.add(line.strip())

    # Menyimpan baris unik ke dalam file output
    with open(output_file, 'w') as outfile:
        outfile.write('\n'.join(unique_lines))

# Meminta input dari pengguna untuk nama file input dan output
input_filename = input("Masukkan nama file input: ")
output_filename = input("Masukkan nama file output: ")

remove_duplicate_lines(input_filename, output_filename)
print(f"Baris unik telah disimpan dalam {output_filename}")
