import requests
import urllib3
import os
import random
import sys
import time
from multiprocessing.dummy import Pool as ThreadPool
from colorama import init, Fore

init()
urllib3.disable_warnings()

# Now regular ANSI codes should work, even in Windows
RED = Fore.RED
RESET = Fore.RESET
WHITE = Fore.WHITE

def print_logo():
    clear = "\x1b[0m"
    colors = [31, 32, 33, 34, 35, 36, 37, 38, 39]

    x = """


            THE FUCKING YOU MOM BRO🖕🖕
                           
                          
                                                        
"""
    for N, line in enumerate(x.split("\n")):
        sys.stdout.write("\x1b[1;%dm%s%s\n" % (random.choice(colors), line, clear))
        time.sleep(0.02)

print_logo()

if not os.path.exists("cms"):
    os.mkdir("cms", 0o755)

header = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}

def lightxcms(site):
    site = site.replace('\n', '').replace('\r', '')
    if site.startswith('https://'):
        site = site.replace('https://', 'http://')
    elif site.startswith('http://'):
        pass
    else:
        site = 'http://'+site
    try:
        payload = requests.get(site, headers=header, verify=False, timeout=20, allow_redirects=True)
        if payload.status_code == 200:
            if 'content="PrestaShop"' in payload.text:
                print("[+] PRESTASHOP :: " + site)
                open('cms/Preatshop.txt', 'a').write(site+'\n')
            elif 'catalog/view/' in payload.text:
                print("[+] OpenCart :: " + site)
                open('cms/OpenCart.txt', 'a').write(site+'\n')
            elif 'meta name="generator" content="vBulletin' in payload.text:
                print("[+] vBulletin :: " + site)
                open('vBulletin.txt', 'a').write(site+'\n')
            elif '/sites/default/' in payload.text:
                print("[+] Drupal :: " + site)
                open('cms/Drupal.txt', 'a').write(site+'\n')
            elif 'laravel_session' in payload.text:
                print("[+] Laravel :: " + site)
                open('cms/Laravel.txt', 'a').write(site+'\n')
            else:
                for dirx in ['/media/system/js/core.js', '/wp-includes/js/jquery/jquery.js']:
                    payload2 = requests.get(site+dirx, headers=header, verify=False, timeout=20, allow_redirects=True)
                    if 'jQuery' in payload2.text:
                        print("[+] Wordpress :: " + site)
                        open('cms/Wordpress.txt', 'a').write(site+'\n')
                        break
                    elif 'window.Joomla' in payload2.text:
                        print("[+] Joomla :: " + site)
                        open('cms/Joomla.txt', 'a').write(site+'\n')
                        break
                    else:
                        print("[+] UNKNOWN :: " + site)
                        open('cms/Unknown.txt', 'a').write(site+'\n')
        else:
            print("[+] UNKNOWN :: " + site)
            open('cms/Unknown.txt', 'a').write(site+'\n')
    except:
        print(RED + "[+] DEAD SITE :: " + site)

def multixcms():
    sitex = open(input(RED + 'site list: ' + WHITE), 'r').readlines()
    td = input("THREADS : ")  
    pool = ThreadPool(int(td))
    pool.map(lightxcms, sitex)
    pool.close()
    pool.join()

multixcms()
